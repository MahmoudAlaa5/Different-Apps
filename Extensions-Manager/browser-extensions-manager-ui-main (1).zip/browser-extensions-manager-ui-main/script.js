// Filter buttons (match data-filter attributes in HTML)
const allBtn = document.querySelector('[data-filter="all"]');
const activeBtn = document.querySelector('[data-filter="active"]');
const inactiveBtn = document.querySelector('[data-filter="inactive"]');


async function getDataAsync() {
  try {
    const response = await fetch('data.json');
    const data = await response.json();
    
    return data;
  } catch (error) {
    console.error('Error:', error);
  }
}


// Fix 1: Use await (Recommended)
async function loadData() {
  let data = await getDataAsync();
  displayExtensions(data)
  
}


function displayExtensions(data) {
  let extensions = document.querySelector('.extensions');
  
  // Clear existing content
  extensions.innerHTML = '';
  
  for (let i = 0; i < data.length; i++) {
    let extension = data[i];
    
    // Create the main extension card
    let extensionCard = document.createElement('div');
    extensionCard.classList.add('extension-card');
    
    // Create the HTML structure with actual data
    extensionCard.innerHTML = `
      <div class="extension-header">
        <div class="extension-icon">
          <img src="${extension.logo}" alt="${extension.name} icon" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
          <div style="display:none; color: white; font-size: 12px; text-align: center;">📱</div>
        </div>
        <div class="extension-info">
          <h3 class="extension-title">${extension.name}</h3>
          <p class="extension-description">${extension.description}</p>
        </div>
      </div>
      <div class="extension-controls">
        <button class="remove-button">Remove</button>
        <label class="toggle-switch">
          <input type="checkbox" ${extension.isActive ? 'checked' : ''} onchange="toggleExtension('${extension.name}', this.checked)">
          <span class="toggle-slider"></span>
        </label>
      </div>
    `;
    
    
    
    extensions.appendChild(extensionCard);
  }
}


// Add event listener to the remove button AFTER creating the HTML
document.querySelector('.extensions').addEventListener('click', (e) => {
  const btn = e.target.closest('.remove-button');
  if (!btn) return;
  const card = btn.closest('.extension-card');
  if (card) card.remove();
});





// Function to toggle extension
function toggleExtension(name, isActive) {
  'Toggling extension:', name, 'to', isActive ? 'active' : 'inactive';
  // Add your toggle logic here
}


// Show all cards
function displayAllCards() {
  const cards = document.querySelectorAll('.extension-card');
  cards.forEach(card => {
    card.style.display = '';
  });
}

// Show only active cards (based on checkbox state)
function displayActiveCards() {
  const cards = document.querySelectorAll('.extension-card');
  cards.forEach(card => {
    const isActive = card.querySelector('input[type="checkbox"]').checked;
    card.style.display = isActive ? '' : 'none';
  });
}

// Show only inactive cards
function displayInactiveCards() {
  const cards = document.querySelectorAll('.extension-card');
  cards.forEach(card => {
    const isActive = card.querySelector('input[type="checkbox"]').checked;
    card.style.display = isActive ? 'none' : '';
  });
}


// Wire up filter buttons (after DOM ready)
function setupFilters() {
  if (allBtn) allBtn.addEventListener('click', displayAllCards);
  if (activeBtn) activeBtn.addEventListener('click', displayActiveCards);
  if (inactiveBtn) inactiveBtn.addEventListener('click', displayInactiveCards);
}


function toggleTheme() {
  const body = document.body;
  body.classList.toggle('lightMode');
  body.classList.toggle('darkMode');
}


function controlsFocus() {
  const filterGroup = document.querySelector('.filter-controls');
  const filterBtns = Array.from(document.querySelectorAll('.filter-btn'));

  filterGroup.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    btn.focus(); // move focus to the clicked button
});

}




addEventListener('DOMContentLoaded', () => {
  loadData();
  setupFilters();
  controlsFocus();
})
