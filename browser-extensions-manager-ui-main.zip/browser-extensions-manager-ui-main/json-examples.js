// ========================================
// SIMPLE WAYS TO ACCESS JSON DATA
// ========================================

// Method 1: Direct fetch with .then() (Most common)
fetch('data.json')
  .then(response => response.json())
  .then(data => {
    // Access the entire array
    console.log('All data:', data);
    
    // Access first item
    console.log('First item:', data[0]);
    
    // Access specific properties
    console.log('First extension name:', data[0].name);
    console.log('First extension description:', data[0].description);
    
    // Count total extensions
    console.log('Total extensions:', data.length);
  });

// Method 2: Using async/await (Cleaner syntax)
async function loadData() {
  const response = await fetch('data.json');
  const data = await response.json();
  
  // Now you can use the data
  console.log('Data loaded:', data);
  
  // Filter active extensions
  const active = data.filter(item => item.isActive);
  console.log('Active extensions:', active);
  
  return data;
}

// Method 3: Store data in a variable for reuse
let myData = [];

fetch('data.json')
  .then(response => response.json())
  .then(data => {
    myData = data;
    console.log('Data stored in myData variable');
  });

// Method 4: Simple utility functions
function getAllExtensions() {
  return myData;
}

function getActiveExtensions() {
  return myData.filter(ext => ext.isActive);
}

function getInactiveExtensions() {
  return myData.filter(ext => !ext.isActive);
}

function findExtension(name) {
  return myData.find(ext => ext.name === name);
}

function getExtensionCount() {
  return myData.length;
}

// Method 5: Working with specific data
function displayExtensions() {
  myData.forEach((extension, index) => {
    console.log(`${index + 1}. ${extension.name}`);
    console.log(`   Description: ${extension.description}`);
    console.log(`   Status: ${extension.isActive ? 'Active' : 'Inactive'}`);
    console.log(`   Logo: ${extension.logo}`);
    console.log('---');
  });
}

// Method 6: Search and filter
function searchExtensions(searchTerm) {
  return myData.filter(ext => 
    ext.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ext.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
}

// Method 7: Update data
function toggleExtension(name) {
  const extension = findExtension(name);
  if (extension) {
    extension.isActive = !extension.isActive;
    console.log(`${name} is now ${extension.isActive ? 'active' : 'inactive'}`);
  }
}

// Method 8: Get statistics
function getStats() {
  const total = myData.length;
  const active = myData.filter(ext => ext.isActive).length;
  const inactive = total - active;
  
  return {
    total,
    active,
    inactive,
    activePercentage: Math.round((active / total) * 100)
  };
}

// ========================================
// USAGE EXAMPLES
// ========================================

// Load data and then use it
loadData().then(data => {
  console.log('Data loaded successfully!');
  
  // Example: Display all active extensions
  const activeExtensions = data.filter(ext => ext.isActive);
  console.log('Active extensions:', activeExtensions);
  
  // Example: Find a specific extension
  const devLens = data.find(ext => ext.name === 'DevLens');
  if (devLens) {
    console.log('Found DevLens:', devLens);
  }
  
  // Example: Get all extension names
  const names = data.map(ext => ext.name);
  console.log('All extension names:', names);
});

// ========================================
// QUICK REFERENCE
// ========================================

/*
ACCESSING JSON DATA:

1. Get all data: data
2. Get first item: data[0]
3. Get specific property: data[0].name
4. Get all names: data.map(item => item.name)
5. Filter active: data.filter(item => item.isActive)
6. Find specific: data.find(item => item.name === 'DevLens')
7. Count items: data.length
8. Loop through: data.forEach((item, index) => { ... })

COMMON PATTERNS:

- Filter: data.filter(item => condition)
- Find: data.find(item => condition)
- Map: data.map(item => newValue)
- ForEach: data.forEach(item => doSomething(item))
- Some: data.some(item => condition)
- Every: data.every(item => condition)
*/


